Content of this folder:

./abapdoc/

Contains the exported documentation for the selected classes and interfaces. Each object is stored in its ABAP package e.g.

+---package
    \---subpackage
        \---classes
            \---cl_abap_class


./htmldesign/

Contains the html stylesheet. It can be used to change the design of the generated documentation.